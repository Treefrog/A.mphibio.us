Classic theme for A.mphibio.us
===============================================

###Classic Theme for A.mphibio.us

This theme is provided for a quick start to your project.

## Authors

Authored by Clive Moore (clive@lassosoft.com) 

## License Information

All parts of A.mphibio.us are free to use and abuse under the open-source MIT license.
The full licensing language can be found here: http://www.opensource.org/licenses/mit-license.php
LassoSoft Inc (http://www.lassosoft.com), (http://a.mphibio.us).