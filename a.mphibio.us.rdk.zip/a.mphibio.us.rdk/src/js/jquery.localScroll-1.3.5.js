/**
 * Copyright (c) 2007-2014 Ariel Flesler - aflesler<a>gmail<d>com | http://flesler.blogspot.com
 * Licensed under MIT
 * @author Ariel Flesler
 * @version 1.3.5
 */

;
(function(a) {
    if (typeof define === 'function' && define.amd) {
        define(['jquery'], a)
    } else {
        a(jQuery)
    }
}(function($) {
    var g = location.href.replace(/#.*/, '');
    var h = $.localScroll = function(a) {
        $('body').localScroll(a)
    };
    h.defaults = {
        duration: 1000,
        axis: 'y',
        event: 'click',
        stop: true,
        target: window
    };
    $.fn.localScroll = function(a) {
        a = $.extend({}, h.defaults, a);
        if (a.hash && location.hash) {
            if (a.target)
                window.scrollTo(0, 0);
            scroll(0, location, a)
        }
        return a.lazy ? this.on(a.event, 'a,area', function(e) {
            if (filter.call(this)) {
                scroll(e, this, a)
            }
        }) : this.find('a,area').filter(filter).bind(a.event, function(e) {
            scroll(e, this, a)
        }).end().end();
        function filter() {
            return !!this.href&&!!this.hash && this.href.replace(this.hash, '') == g && (!a.filter || $(this).is(a.filter))
        }
    };
    h.hash = function() {};
    function scroll(e, a, b) {
        var c = a.hash.slice(1), elem = document.getElementById(c) || document.getElementsByName(c)[0];
        if (!elem)
            return;
        if (e)
            e.preventDefault();
        var d = $(b.target);
        if (b.lock && d.is(':animated') || b.onBefore && b.onBefore(e, elem, d) === false)
            return;
        if (b.stop)
            d._scrollable().stop(true);
        if (b.hash) {
            var f = elem.id === c ? 'id': 'name', $a = $('<a> </a>').attr(f, c).css({
                position: 'absolute',
                top: $(window).scrollTop(),
                left: $(window).scrollLeft()
            });
            elem[f] = '';
            $('body').prepend($a);
            location.hash = a.hash;
            $a.remove();
            elem[f] = c
        }
        d.scrollTo(elem, b).trigger('notify.serialScroll', [elem])
    };
    return h
}));
