Themes for A.mphibio.us
===============================================

###Overview.

These theme files are currently in development and are provided as is to provide a quick start to your project.

## Authors

Authored by Clive Moore (clive@lassosoft.com) and Jennifer Hawkyard (jen@treefrog.ca) 

## License Information

All parts of A.mphibio.us are free to use and abuse under the open-source MIT license. The full licensing language can be found here: http://www.opensource.org/licenses/mit-license.php.
LassoSoft Inc (http://www.lassosoft.com), (http://a.mphibio.us).